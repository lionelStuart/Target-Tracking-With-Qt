<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="zh_CN">
<context>
    <name>CoopLocationWidget</name>
    <message>
        <location filename="../GUI/cooplocationwidget.ui" line="14"/>
        <source>CoopLocationWidget</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/cooplocationwidget.ui" line="26"/>
        <source>输入视频</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/cooplocationwidget.ui" line="124"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-size:10pt; color:#55aaff;&quot;&gt;通道 2&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/cooplocationwidget.ui" line="140"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-size:10pt; color:#55aaff;&quot;&gt;通道 1&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/cooplocationwidget.ui" line="154"/>
        <source>地图</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/cooplocationwidget.ui" line="200"/>
        <source>通道 1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/cooplocationwidget.ui" line="223"/>
        <location filename="../GUI/cooplocationwidget.ui" line="584"/>
        <source>加载视频</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/cooplocationwidget.ui" line="237"/>
        <location filename="../GUI/cooplocationwidget.ui" line="598"/>
        <source>加载位姿参数</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/cooplocationwidget.ui" line="247"/>
        <location filename="../GUI/cooplocationwidget.ui" line="608"/>
        <source>加载分类器</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/cooplocationwidget.ui" line="313"/>
        <location filename="../GUI/cooplocationwidget.ui" line="674"/>
        <source>0000/9999</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/cooplocationwidget.ui" line="335"/>
        <source>运行控制</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/cooplocationwidget.ui" line="363"/>
        <source>运行</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/cooplocationwidget.ui" line="373"/>
        <source>结束</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/cooplocationwidget.ui" line="353"/>
        <source>加载地图</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/cooplocationwidget.ui" line="531"/>
        <source>协同跟踪  控制 / 显示台</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/cooplocationwidget.ui" line="561"/>
        <source>通道 2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/cooplocationwidget.cpp" line="77"/>
        <location filename="../GUI/cooplocationwidget.cpp" line="92"/>
        <source>open Video File</source>
        <translation>打开视频文件路径</translation>
    </message>
    <message>
        <location filename="../GUI/cooplocationwidget.cpp" line="77"/>
        <location filename="../GUI/cooplocationwidget.cpp" line="92"/>
        <source>All files(*.*);;video files(*.avi;*.mpg)</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../GUI/cooplocationwidget.cpp" line="107"/>
        <location filename="../GUI/cooplocationwidget.cpp" line="121"/>
        <source>open Xml File</source>
        <translation>打开XML文件路径</translation>
    </message>
    <message>
        <location filename="../GUI/cooplocationwidget.cpp" line="135"/>
        <location filename="../GUI/cooplocationwidget.cpp" line="152"/>
        <source>open text File</source>
        <translation>打开TXT文件路径</translation>
    </message>
    <message>
        <location filename="../GUI/cooplocationwidget.cpp" line="107"/>
        <location filename="../GUI/cooplocationwidget.cpp" line="121"/>
        <source>detector files(*.xml)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/cooplocationwidget.cpp" line="135"/>
        <location filename="../GUI/cooplocationwidget.cpp" line="152"/>
        <source>text files(*.txt)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/cooplocationwidget.cpp" line="170"/>
        <location filename="../GUI/cooplocationwidget.cpp" line="265"/>
        <source>pause</source>
        <translation>暂停</translation>
    </message>
    <message>
        <location filename="../GUI/cooplocationwidget.cpp" line="174"/>
        <location filename="../GUI/cooplocationwidget.cpp" line="182"/>
        <location filename="../GUI/cooplocationwidget.cpp" line="194"/>
        <source>run</source>
        <translation>运行</translation>
    </message>
    <message>
        <location filename="../GUI/cooplocationwidget.cpp" line="199"/>
        <source>open Image File</source>
        <translation>打开图像文件路径</translation>
    </message>
    <message>
        <location filename="../GUI/cooplocationwidget.cpp" line="199"/>
        <source>All files(*.*);;image files(*.jpeg;;*.jpg;;*.png)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/cooplocationwidget.cpp" line="275"/>
        <source>information clear</source>
        <translation>清空信息</translation>
    </message>
    <message>
        <location filename="../GUI/cooplocationwidget.cpp" line="231"/>
        <source>Channel 1 video loaded	</source>
        <translation>通道 1载入视频</translation>
    </message>
    <message>
        <location filename="../GUI/cooplocationwidget.cpp" line="34"/>
        <location filename="../GUI/cooplocationwidget.cpp" line="232"/>
        <location filename="../GUI/cooplocationwidget.cpp" line="244"/>
        <source>Width:%2m   Height:%3m</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/cooplocationwidget.cpp" line="243"/>
        <source>Channel 2 video loaded	</source>
        <translation>通道 2载入视频</translation>
    </message>
    <message>
        <location filename="../GUI/cooplocationwidget.cpp" line="255"/>
        <source>Channel 1 detector loaded	</source>
        <translation>通道 1载入检测器</translation>
    </message>
    <message>
        <location filename="../GUI/cooplocationwidget.cpp" line="260"/>
        <source>Channel 2 detector loaded	</source>
        <translation>通道 2载入检测器</translation>
    </message>
    <message>
        <location filename="../GUI/cooplocationwidget.cpp" line="270"/>
        <source>running</source>
        <translation>运行中...</translation>
    </message>
    <message>
        <location filename="../GUI/cooplocationwidget.cpp" line="278"/>
        <source>stopped</source>
        <translation>工作停止</translation>
    </message>
    <message>
        <location filename="../GUI/cooplocationwidget.cpp" line="283"/>
        <source>map loaded</source>
        <translation>载入地图</translation>
    </message>
    <message>
        <location filename="../GUI/cooplocationwidget.cpp" line="286"/>
        <location filename="../GUI/cooplocationwidget.cpp" line="294"/>
        <source>Width:%1m   Height:%2m</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/cooplocationwidget.cpp" line="291"/>
        <source>Channel 1 poseFile loaded	</source>
        <translation>通道 1载入位姿文件</translation>
    </message>
    <message>
        <location filename="../GUI/cooplocationwidget.cpp" line="299"/>
        <source>Channel 2 poseFile loaded	</source>
        <translation>通道 2载入位姿文件</translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../GUI/mainwindow.cpp" line="294"/>
        <source>About</source>
        <translation>关于</translation>
    </message>
    <message>
        <location filename="../GUI/mainwindow.cpp" line="296"/>
        <source>About this software</source>
        <translation>关于本软件</translation>
    </message>
    <message>
        <location filename="../GUI/mainwindow.cpp" line="298"/>
        <source>UAVs tracking experimental platform</source>
        <translation>无人机目标跟踪多任务实验平台</translation>
    </message>
    <message>
        <location filename="../GUI/mainwindow.cpp" line="300"/>
        <source>Version 1.0  </source>
        <translation>版本 1.0</translation>
    </message>
</context>
<context>
    <name>MainWindowClass</name>
    <message>
        <source>MainWindow</source>
        <translation type="obsolete">主窗口界面</translation>
    </message>
    <message>
        <location filename="../GUI/mainwindow.ui" line="14"/>
        <source>无人机目标跟踪多任务实验演示平台</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/mainwindow.ui" line="165"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-size:28pt; color:#c7c7c7;&quot;&gt;无人机目标跟踪多任务实验演示平台&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/mainwindow.ui" line="181"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-size:20pt; font-weight:600; font-style:italic; color:#c31a72;&quot;&gt;西安电子科技大学&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/mainwindow.ui" line="197"/>
        <source>文件(&amp;F)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/mainwindow.ui" line="206"/>
        <source>单目标跟踪(&amp;T)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/mainwindow.ui" line="217"/>
        <source>目标定位(&amp;L)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/mainwindow.ui" line="228"/>
        <source>目标检测(&amp;D)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/mainwindow.ui" line="235"/>
        <source>多目标跟踪(&amp;M)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/mainwindow.ui" line="244"/>
        <source>帮助(&amp;H)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/mainwindow.ui" line="257"/>
        <source>单无人机跟踪</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/mainwindow.ui" line="262"/>
        <location filename="../GUI/mainwindow.ui" line="322"/>
        <source>粒子滤波</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/mainwindow.ui" line="267"/>
        <source>读取视频</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/mainwindow.ui" line="272"/>
        <location filename="../GUI/mainwindow.ui" line="297"/>
        <source>CT</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/mainwindow.ui" line="277"/>
        <location filename="../GUI/mainwindow.ui" line="307"/>
        <source>Hash</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/mainwindow.ui" line="282"/>
        <location filename="../GUI/mainwindow.ui" line="302"/>
        <source>KCF</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/mainwindow.ui" line="287"/>
        <location filename="../GUI/mainwindow.ui" line="312"/>
        <source>STC</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/mainwindow.ui" line="292"/>
        <location filename="../GUI/mainwindow.ui" line="317"/>
        <source>STRUCK</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/mainwindow.ui" line="327"/>
        <source>运动检测</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/mainwindow.ui" line="330"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Motion Detect&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/mainwindow.ui" line="335"/>
        <source>分类器检测</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/mainwindow.ui" line="340"/>
        <source>协同跟踪</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/mainwindow.ui" line="345"/>
        <source>关于本软件</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/mainwindow.ui" line="350"/>
        <source>返回</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/mainwindow.ui" line="355"/>
        <location filename="../GUI/mainwindow.ui" line="358"/>
        <source>关闭</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/mainwindow.ui" line="363"/>
        <source>单无人机定位</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>MotionDetectionWidget</name>
    <message>
        <location filename="../GUI/motiondetectionwidget.ui" line="26"/>
        <source>MotionDetectionWidget</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/motiondetectionwidget.ui" line="119"/>
        <source>播放</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/motiondetectionwidget.ui" line="141"/>
        <source>结束</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/motiondetectionwidget.ui" line="200"/>
        <source>0000/9999</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/motiondetectionwidget.ui" line="222"/>
        <source>信息显示</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/motiondetectionwidget.ui" line="254"/>
        <source>运动区域</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/motiondetectionwidget.ui" line="305"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; color:#a7a7a7;&quot;&gt;无人机目标跟踪多任务实验演示平台--&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/motiondetectionwidget.ui" line="322"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-style:italic; color:#ec2643;&quot;&gt;运动目标检测&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/motiondetectionwidget.cpp" line="59"/>
        <location filename="../GUI/motiondetectionwidget.cpp" line="70"/>
        <location filename="../GUI/motiondetectionwidget.cpp" line="112"/>
        <source>play</source>
        <translation>播放</translation>
    </message>
    <message>
        <location filename="../GUI/motiondetectionwidget.cpp" line="61"/>
        <source>pause</source>
        <translation>暂停</translation>
    </message>
    <message>
        <location filename="../GUI/motiondetectionwidget.cpp" line="101"/>
        <source>open file path:	</source>
        <translation>打开文件路径:</translation>
    </message>
    <message>
        <location filename="../GUI/motiondetectionwidget.cpp" line="106"/>
        <source>video param:	 resolution:%1*%2  length:%3</source>
        <translation>视频参数： 分辨率：%1*%2 长度：%3</translation>
    </message>
    <message>
        <location filename="../GUI/motiondetectionwidget.cpp" line="113"/>
        <source>video pause</source>
        <translation>视频暂停中\</translation>
    </message>
    <message>
        <location filename="../GUI/motiondetectionwidget.cpp" line="115"/>
        <source>video running</source>
        <translation>视频运行中...</translation>
    </message>
    <message>
        <location filename="../GUI/motiondetectionwidget.cpp" line="118"/>
        <source>start detection</source>
        <translation>开始检测</translation>
    </message>
    <message>
        <location filename="../GUI/motiondetectionwidget.cpp" line="124"/>
        <source>video stopped</source>
        <translation>视频结束播放</translation>
    </message>
</context>
<context>
    <name>MultiLocationWidget</name>
    <message>
        <location filename="../GUI/multilocationwidget.ui" line="14"/>
        <source>MultiLocationWidget</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/multilocationwidget.ui" line="104"/>
        <source>运行</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/multilocationwidget.ui" line="126"/>
        <source>结束</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/multilocationwidget.ui" line="185"/>
        <source>0000/9999</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/multilocationwidget.ui" line="425"/>
        <source>检测器</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/multilocationwidget.ui" line="453"/>
        <source>姿态参数</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/multilocationwidget.ui" line="481"/>
        <source>加载地图</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/multilocationwidget.ui" line="500"/>
        <source>信息显示</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/multilocationwidget.ui" line="551"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; color:#a7a7a7;&quot;&gt;无人机目标跟踪多任务实验演示平台--&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/multilocationwidget.ui" line="568"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-style:italic; color:#ec2643;&quot;&gt;单无人机定位&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/multilocationwidget.cpp" line="70"/>
        <location filename="../GUI/multilocationwidget.cpp" line="85"/>
        <location filename="../GUI/multilocationwidget.cpp" line="95"/>
        <location filename="../GUI/multilocationwidget.cpp" line="124"/>
        <location filename="../GUI/multilocationwidget.cpp" line="154"/>
        <location filename="../GUI/multilocationwidget.cpp" line="208"/>
        <source>play</source>
        <translation>运行</translation>
    </message>
    <message>
        <location filename="../GUI/multilocationwidget.cpp" line="72"/>
        <source>pause</source>
        <translation>暂停</translation>
    </message>
    <message>
        <location filename="../GUI/multilocationwidget.cpp" line="100"/>
        <source>open xml File</source>
        <translation>打开XML文件路径</translation>
    </message>
    <message>
        <location filename="../GUI/multilocationwidget.cpp" line="100"/>
        <source>detector files(*.xml)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/multilocationwidget.cpp" line="129"/>
        <source>open txt File</source>
        <translation>打开txt文件</translation>
    </message>
    <message>
        <location filename="../GUI/multilocationwidget.cpp" line="129"/>
        <source>poseFile(*.txt)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/multilocationwidget.cpp" line="161"/>
        <source>open Image File</source>
        <translation>打开图像文件路径</translation>
    </message>
    <message>
        <location filename="../GUI/multilocationwidget.cpp" line="161"/>
        <source>All files(*.*);;image files(*.jpeg;;*.jpg;;*.png)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/multilocationwidget.cpp" line="192"/>
        <source>FOV:%1degrees   Width:%2m   Height:%3m</source>
        <translation>FOV:%1度   地形宽:%2m   地形高:%3m</translation>
    </message>
    <message>
        <location filename="../GUI/multilocationwidget.cpp" line="197"/>
        <source>open file path:	</source>
        <translation>打开文件路径:</translation>
    </message>
    <message>
        <location filename="../GUI/multilocationwidget.cpp" line="202"/>
        <source>video param:	 resolution:%1*%2  length:%3</source>
        <translation>视频参数： 分辨率：%1*%2 长度：%3</translation>
    </message>
    <message>
        <location filename="../GUI/multilocationwidget.cpp" line="209"/>
        <source>video pause</source>
        <translation>视频暂停中\</translation>
    </message>
    <message>
        <location filename="../GUI/multilocationwidget.cpp" line="211"/>
        <source>video running</source>
        <translation>视频运行中...</translation>
    </message>
    <message>
        <location filename="../GUI/multilocationwidget.cpp" line="216"/>
        <source>video stopped</source>
        <translation>视频结束播放</translation>
    </message>
    <message>
        <location filename="../GUI/multilocationwidget.cpp" line="221"/>
        <source>uninitialized param exists</source>
        <translation>存在未初始化的参数</translation>
    </message>
    <message>
        <location filename="../GUI/multilocationwidget.cpp" line="226"/>
        <source>Detector File Loaded  :	</source>
        <translation>加载检测器文件:</translation>
    </message>
    <message>
        <location filename="../GUI/multilocationwidget.cpp" line="232"/>
        <source>Detector File Loaded  failed</source>
        <translation>检测器加载错误</translation>
    </message>
    <message>
        <location filename="../GUI/multilocationwidget.cpp" line="237"/>
        <source>PoseFile Loaded  :	</source>
        <translation>位姿文件加载：</translation>
    </message>
    <message>
        <location filename="../GUI/multilocationwidget.cpp" line="243"/>
        <source>Pose File Loaded  failed</source>
        <translation>位姿文件加载错误</translation>
    </message>
    <message>
        <location filename="../GUI/multilocationwidget.cpp" line="248"/>
        <source>Map File Loaded  :	</source>
        <translation>加载地图:</translation>
    </message>
    <message>
        <location filename="../GUI/multilocationwidget.cpp" line="254"/>
        <source>Map File Loaded  failed</source>
        <translation>地图加载失败</translation>
    </message>
</context>
<context>
    <name>MultiTrackingWidget</name>
    <message>
        <location filename="../GUI/multitrackingwidget.ui" line="14"/>
        <source>MultiTrackingWidget</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/multitrackingwidget.ui" line="107"/>
        <source>运行</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/multitrackingwidget.ui" line="129"/>
        <source>结束</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/multitrackingwidget.ui" line="151"/>
        <source>跟踪</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/multitrackingwidget.ui" line="210"/>
        <source>0000/9999</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/multitrackingwidget.ui" line="232"/>
        <source>参数调整</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/multitrackingwidget.ui" line="279"/>
        <source>最小阈值</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/multitrackingwidget.ui" line="315"/>
        <source>最大阈值</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/multitrackingwidget.ui" line="332"/>
        <source>信息显示</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/multitrackingwidget.ui" line="383"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; color:#a7a7a7;&quot;&gt;无人机目标跟踪多任务实验演示平台--&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/multitrackingwidget.ui" line="400"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-style:italic; color:#ec2643;&quot;&gt;多目标跟踪&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/multitrackingwidget.cpp" line="72"/>
        <location filename="../GUI/multitrackingwidget.cpp" line="84"/>
        <location filename="../GUI/multitrackingwidget.cpp" line="94"/>
        <location filename="../GUI/multitrackingwidget.cpp" line="150"/>
        <source>play</source>
        <translation>运行</translation>
    </message>
    <message>
        <location filename="../GUI/multitrackingwidget.cpp" line="74"/>
        <source>pause</source>
        <translation>暂停</translation>
    </message>
    <message>
        <location filename="../GUI/multitrackingwidget.cpp" line="100"/>
        <source>open xml File</source>
        <translation>打开XML文件路径</translation>
    </message>
    <message>
        <location filename="../GUI/multitrackingwidget.cpp" line="100"/>
        <source>detector files(*.xml)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/multitrackingwidget.cpp" line="139"/>
        <source>open file path:	</source>
        <translation>打开文件路径:</translation>
    </message>
    <message>
        <location filename="../GUI/multitrackingwidget.cpp" line="144"/>
        <source>video param:	 resolution:%1*%2  length:%3</source>
        <translation>视频参数： 分辨率：%1*%2 长度：%3</translation>
    </message>
    <message>
        <location filename="../GUI/multitrackingwidget.cpp" line="151"/>
        <source>video pause</source>
        <translation>视频暂停中\</translation>
    </message>
    <message>
        <location filename="../GUI/multitrackingwidget.cpp" line="153"/>
        <source>video running</source>
        <translation>视频运行中...</translation>
    </message>
    <message>
        <location filename="../GUI/multitrackingwidget.cpp" line="158"/>
        <source>video stopped</source>
        <translation>视频结束播放</translation>
    </message>
    <message>
        <location filename="../GUI/multitrackingwidget.cpp" line="163"/>
        <source>load detector:	</source>
        <translation>载入检测器</translation>
    </message>
    <message>
        <location filename="../GUI/multitrackingwidget.cpp" line="167"/>
        <source>if you&apos;ve select video input ,then press start button to detect targets</source>
        <translation>如已读入图片，点击运行键检测目标</translation>
    </message>
    <message>
        <location filename="../GUI/multitrackingwidget.cpp" line="172"/>
        <source>load detector failure</source>
        <translation>加载检测器错误</translation>
    </message>
</context>
<context>
    <name>QVideoProcessor</name>
    <message>
        <location filename="../VideoProcessor/QVideoProcessor.cpp" line="57"/>
        <source>open Video File</source>
        <translation>打开视频文件路径</translation>
    </message>
    <message>
        <location filename="../VideoProcessor/QVideoProcessor.cpp" line="57"/>
        <source>All files(*.*);;video files(*.avi;*.mpg)</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>TargetLocationWidget</name>
    <message>
        <location filename="../GUI/targetlocationwidget.ui" line="14"/>
        <source>TargetLocationWidget</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/targetlocationwidget.ui" line="107"/>
        <source>播放</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/targetlocationwidget.ui" line="129"/>
        <source>结束</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/targetlocationwidget.ui" line="151"/>
        <source>画框</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/targetlocationwidget.ui" line="210"/>
        <source>0000/9999</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/targetlocationwidget.ui" line="478"/>
        <source>加载地图</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/targetlocationwidget.ui" line="450"/>
        <source>姿态参数</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/targetlocationwidget.ui" line="497"/>
        <source>信息显示</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/targetlocationwidget.ui" line="548"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; color:#a7a7a7;&quot;&gt;无人机目标跟踪多任务实验演示平台--&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/targetlocationwidget.ui" line="565"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-style:italic; color:#ec2643;&quot;&gt;单目标定位&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/targetlocationwidget.cpp" line="66"/>
        <location filename="../GUI/targetlocationwidget.cpp" line="77"/>
        <location filename="../GUI/targetlocationwidget.cpp" line="89"/>
        <location filename="../GUI/targetlocationwidget.cpp" line="225"/>
        <source>play</source>
        <translation>播放</translation>
    </message>
    <message>
        <location filename="../GUI/targetlocationwidget.cpp" line="68"/>
        <location filename="../GUI/targetlocationwidget.cpp" line="164"/>
        <source>pause</source>
        <translation>暂停</translation>
    </message>
    <message>
        <location filename="../GUI/targetlocationwidget.cpp" line="104"/>
        <source>open text File</source>
        <translation>打开TXT文件路径</translation>
    </message>
    <message>
        <location filename="../GUI/targetlocationwidget.cpp" line="104"/>
        <source>txt files(*.txt)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/targetlocationwidget.cpp" line="134"/>
        <source>open Image File</source>
        <translation>打开图像文件路径</translation>
    </message>
    <message>
        <location filename="../GUI/targetlocationwidget.cpp" line="134"/>
        <source>image files(*.jpg;*.png;*.bmp)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/targetlocationwidget.cpp" line="195"/>
        <location filename="../GUI/targetlocationwidget.cpp" line="217"/>
        <location filename="../GUI/targetlocationwidget.cpp" line="254"/>
        <source>FOV:%1degrees   Width:%2m   Height:%3m</source>
        <translation>FOV:%1度   地形宽:%2m   地形高:%3m</translation>
    </message>
    <message>
        <location filename="../GUI/targetlocationwidget.cpp" line="200"/>
        <source>open file path:	</source>
        <translation>打开文件路径:</translation>
    </message>
    <message>
        <location filename="../GUI/targetlocationwidget.cpp" line="205"/>
        <source>video param:	 resolution:%1*%2  length:%3</source>
        <translation>视频参数： 分辨率：%1*%2 长度：%3</translation>
    </message>
    <message>
        <location filename="../GUI/targetlocationwidget.cpp" line="209"/>
        <location filename="../GUI/targetlocationwidget.cpp" line="215"/>
        <source>select tracking method:	</source>
        <translation>选择跟踪方法:</translation>
    </message>
    <message>
        <location filename="../GUI/targetlocationwidget.cpp" line="226"/>
        <source>video pause</source>
        <translation>视频暂停中\</translation>
    </message>
    <message>
        <location filename="../GUI/targetlocationwidget.cpp" line="228"/>
        <source>video running</source>
        <translation>视频运行中...</translation>
    </message>
    <message>
        <location filename="../GUI/targetlocationwidget.cpp" line="233"/>
        <source>video stopped</source>
        <translation>视频结束播放</translation>
    </message>
    <message>
        <location filename="../GUI/targetlocationwidget.cpp" line="238"/>
        <source>pause to draw rect,press ok to continue</source>
        <translation>暂停画框，按确定继续</translation>
    </message>
    <message>
        <location filename="../GUI/targetlocationwidget.cpp" line="243"/>
        <source>get init target:</source>
        <translation>获取初始目标：</translation>
    </message>
    <message>
        <location filename="../GUI/targetlocationwidget.cpp" line="248"/>
        <source>start tracking...</source>
        <translation>开始跟踪...</translation>
    </message>
    <message>
        <location filename="../GUI/targetlocationwidget.cpp" line="253"/>
        <source>PoseFile Loaded  !</source>
        <translation>位姿文件加载成功!</translation>
    </message>
    <message>
        <location filename="../GUI/targetlocationwidget.cpp" line="262"/>
        <source>Map Loaded ! Why is a raven like a writing desk? </source>
        <translation>地图加载成功!若地图未显示，请先加载位姿文件!</translation>
    </message>
</context>
<context>
    <name>TargetRecognitionWidget</name>
    <message>
        <location filename="../GUI/targetrecognitionwidget.ui" line="14"/>
        <source>TargetRecognitionWidget</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/targetrecognitionwidget.ui" line="107"/>
        <source>播放</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/targetrecognitionwidget.ui" line="129"/>
        <source>结束</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/targetrecognitionwidget.ui" line="151"/>
        <source>检测</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/targetrecognitionwidget.ui" line="210"/>
        <source>0000/9999</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/targetrecognitionwidget.ui" line="232"/>
        <source>信息显示</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/targetrecognitionwidget.ui" line="264"/>
        <source>参数调整</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/targetrecognitionwidget.ui" line="311"/>
        <source>最小阈值</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/targetrecognitionwidget.ui" line="347"/>
        <source>最大阈值</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/targetrecognitionwidget.ui" line="383"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; color:#a7a7a7;&quot;&gt;无人机目标跟踪多任务实验演示平台--&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/targetrecognitionwidget.ui" line="400"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-style:italic; color:#ec2643;&quot;&gt;目标识别&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/targetrecognitionwidget.cpp" line="72"/>
        <location filename="../GUI/targetrecognitionwidget.cpp" line="83"/>
        <location filename="../GUI/targetrecognitionwidget.cpp" line="93"/>
        <location filename="../GUI/targetrecognitionwidget.cpp" line="150"/>
        <source>play</source>
        <translation>播放</translation>
    </message>
    <message>
        <location filename="../GUI/targetrecognitionwidget.cpp" line="74"/>
        <source>pause</source>
        <translation>暂停</translation>
    </message>
    <message>
        <location filename="../GUI/targetrecognitionwidget.cpp" line="99"/>
        <source>open xml File</source>
        <translation>打开XML文件路径</translation>
    </message>
    <message>
        <location filename="../GUI/targetrecognitionwidget.cpp" line="99"/>
        <source>detector files(*.xml)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/targetrecognitionwidget.cpp" line="139"/>
        <source>open file path:	</source>
        <translation>打开文件路径:</translation>
    </message>
    <message>
        <location filename="../GUI/targetrecognitionwidget.cpp" line="144"/>
        <source>video param:	 resolution:%1*%2  length:%3</source>
        <translation>视频参数： 分辨率：%1*%2 长度：%3</translation>
    </message>
    <message>
        <location filename="../GUI/targetrecognitionwidget.cpp" line="151"/>
        <source>video pause</source>
        <translation>视频暂停中\</translation>
    </message>
    <message>
        <location filename="../GUI/targetrecognitionwidget.cpp" line="154"/>
        <source>video running</source>
        <translation>视频运行中...</translation>
    </message>
    <message>
        <location filename="../GUI/targetrecognitionwidget.cpp" line="159"/>
        <source>video stopped</source>
        <translation>视频结束播放</translation>
    </message>
    <message>
        <location filename="../GUI/targetrecognitionwidget.cpp" line="164"/>
        <source>load detector:	</source>
        <translation>载入检测器:</translation>
    </message>
    <message>
        <location filename="../GUI/targetrecognitionwidget.cpp" line="168"/>
        <source>if you&apos;ve select video input ,then press start button to detect targets</source>
        <translation>如已读入图片，点击运行键检测目标</translation>
    </message>
    <message>
        <location filename="../GUI/targetrecognitionwidget.cpp" line="173"/>
        <source>load detector failure</source>
        <translation>加载检测器错误</translation>
    </message>
</context>
<context>
    <name>TargetTrackingWidget</name>
    <message>
        <location filename="../GUI/targettrackingwidget.ui" line="14"/>
        <source>TargetTrackingWidget</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/targettrackingwidget.ui" line="26"/>
        <source>信息显示</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/targettrackingwidget.ui" line="58"/>
        <source>参数调整</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/targettrackingwidget.ui" line="152"/>
        <source>播放</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/targettrackingwidget.ui" line="174"/>
        <source>结束</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/targettrackingwidget.ui" line="196"/>
        <source>画框</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/targettrackingwidget.ui" line="255"/>
        <source>0000/9999</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/targettrackingwidget.ui" line="296"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; color:#a7a7a7;&quot;&gt;无人机目标跟踪多任务实验演示平台--&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/targettrackingwidget.ui" line="313"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-style:italic; color:#ec2643;&quot;&gt;单目标跟踪&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/targettrackingwidget.cpp" line="111"/>
        <location filename="../GUI/targettrackingwidget.cpp" line="177"/>
        <source>pause</source>
        <translation>暂停</translation>
    </message>
    <message>
        <location filename="../GUI/targettrackingwidget.cpp" line="202"/>
        <source>open file path:	</source>
        <translation>打开文件路径:</translation>
    </message>
    <message>
        <location filename="../GUI/targettrackingwidget.cpp" line="207"/>
        <source>video param:	 resolution:%1*%2  length:%3</source>
        <translation>视频参数： 分辨率：%1*%2 长度：%3</translation>
    </message>
    <message>
        <location filename="../GUI/targettrackingwidget.cpp" line="211"/>
        <location filename="../GUI/targettrackingwidget.cpp" line="217"/>
        <source>select tracking method:	</source>
        <translation>选择跟踪方法:</translation>
    </message>
    <message>
        <location filename="../GUI/targettrackingwidget.cpp" line="225"/>
        <source>video pause</source>
        <translation>视频暂停中\</translation>
    </message>
    <message>
        <location filename="../GUI/targettrackingwidget.cpp" line="227"/>
        <source>video running</source>
        <translation>视频运行中...</translation>
    </message>
    <message>
        <location filename="../GUI/targettrackingwidget.cpp" line="232"/>
        <source>video stopped</source>
        <translation>视频结束播放</translation>
    </message>
    <message>
        <location filename="../GUI/targettrackingwidget.cpp" line="237"/>
        <source>pause to draw rect,press ok to continue</source>
        <translation>暂停画框，按确定继续</translation>
    </message>
    <message>
        <location filename="../GUI/targettrackingwidget.cpp" line="242"/>
        <source>get init target:</source>
        <translation>获取初始目标：</translation>
    </message>
    <message>
        <location filename="../GUI/targettrackingwidget.cpp" line="247"/>
        <source>start tracking...</source>
        <translation>开始跟踪...</translation>
    </message>
    <message>
        <location filename="../GUI/targettrackingwidget.cpp" line="109"/>
        <location filename="../GUI/targettrackingwidget.cpp" line="120"/>
        <location filename="../GUI/targettrackingwidget.cpp" line="132"/>
        <location filename="../GUI/targettrackingwidget.cpp" line="224"/>
        <source>play</source>
        <translation>播放</translation>
    </message>
</context>
<context>
    <name>drawRectWnd</name>
    <message>
        <location filename="../GUI/drawrectwnd.ui" line="27"/>
        <source>drawRectWnd</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/drawrectwnd.ui" line="48"/>
        <source>确定</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/drawrectwnd.ui" line="70"/>
        <source>TextLabel</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>paramWidget</name>
    <message>
        <location filename="../GUI/paramwidget.ui" line="14"/>
        <source>paramWidget</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/paramwidget.ui" line="26"/>
        <source>粒子滤波</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/paramwidget.ui" line="41"/>
        <source>使用LBP</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/paramwidget.ui" line="80"/>
        <source>粒子数</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/paramwidget.ui" line="97"/>
        <source>Hash</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/paramwidget.ui" line="109"/>
        <source>使用pHash</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/paramwidget.ui" line="123"/>
        <source>Struck</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/paramwidget.ui" line="167"/>
        <source>搜索半径</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/paramwidget.ui" line="184"/>
        <source>KCF</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/paramwidget.ui" line="199"/>
        <source>使用HOG</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/paramwidget.ui" line="219"/>
        <source>固定窗口</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/paramwidget.ui" line="239"/>
        <source>多尺度</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/paramwidget.ui" line="259"/>
        <source>跟踪方法</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/paramwidget.ui" line="295"/>
        <source>确定</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
